import React from "react";
import { AbsoluteFill, interpolate, interpolateColors, useCurrentFrame } from "remotion";
import { Counter, Entrance, NeonCaption, SceneShell, Sfx, clamp01, prog } from "../components/Motion";
import { RingGauge, ShipSvg } from "../components/Ship";
import { f } from "../timeline";
import { theme } from "../theme";

const TEXT = "যাত্রা শুরুর আগেই জাহাজের ভেতরে টানা ১০ দিন ধরে জ্বলছিল ভয়াবহ কয়লার আগুন...";
const HULL = "M20 120 L60 330 Q80 410 180 410 L840 410 Q930 390 985 120 Z";

const Cutaway: React.FC = () => {
  const frame = useCurrentFrame();
  const heat = prog(frame, f(2.4), f(6.0), theme.ease.out);
  const pulse = 0.75 + 0.25 * Math.sin(frame / 10);
  const c = theme.colors;
  return (
    <svg viewBox="0 0 1000 440" width={860} height={378} style={{ overflow: "visible", filter: `drop-shadow(0 0 8px ${c.primary})` }}>
      <defs>
        <radialGradient id="hotGlow">
          <stop offset="0%" stopColor={c.danger} stopOpacity={0.95} />
          <stop offset="45%" stopColor={c.warn} stopOpacity={0.45} />
          <stop offset="100%" stopColor={c.warn} stopOpacity={0} />
        </radialGradient>
        <clipPath id="hullClip">
          <path d={HULL} />
        </clipPath>
      </defs>
      <path d={HULL} fill={`${c.primary}0d`} stroke={c.primary} strokeWidth={3} />
      <g clipPath="url(#hullClip)">
        {[180, 240, 300, 360].map((y) => (
          <line key={y} x1={0} x2={1000} y1={y} y2={y} stroke={c.primary} strokeOpacity={0.3} strokeWidth={1.5} />
        ))}
        {Array.from({ length: 7 }, (_, i) => (
          <line key={i} x1={150 + i * 120} x2={150 + i * 120} y1={120} y2={410} stroke={c.primary} strokeOpacity={0.55} strokeWidth={2} />
        ))}
        {Array.from({ length: 6 }, (_, i) => {
          const n = 1 + i; // 1..6 from aft (left) to forward (right)
          const x = 150 + i * 120;
          return (
            <g key={i}>
              <rect x={x + 8} y={312} width={104} height={90} fill="none" stroke={c.primary} strokeOpacity={0.5} strokeWidth={1.5} strokeDasharray="6 5" />
              <text x={x + 60} y={365} textAnchor="middle" fill={c.primary} fillOpacity={0.8} fontFamily={theme.fonts.mono} fontWeight={700} fontSize={22}>
                BR{n}
              </text>
            </g>
          );
        })}
        <circle cx={810} cy={345} r={170} fill="url(#hotGlow)" opacity={heat * pulse} />
        {Array.from({ length: 7 }, (_, i) => {
          const fl = 0.55 + 0.45 * Math.abs(Math.sin(frame / (5 + i) + i * 1.9));
          const x = 762 + i * 16;
          return (
            <path
              key={i}
              d={`M${x} 404 Q${x - 9} ${404 - 30 * fl} ${x} ${404 - 62 * fl} Q${x + 9} ${404 - 30 * fl} ${x} 404 Z`}
              fill={i % 2 ? c.warn : c.danger}
              opacity={heat}
              style={{ filter: `drop-shadow(0 0 8px ${c.danger})` }}
            />
          );
        })}
      </g>
      <rect x={758} y={252} width={104} height={156} fill="none" stroke={c.danger} strokeWidth={3} opacity={heat} strokeDasharray="10 6" />
      <polyline
        points="810,252 880,120 940,120"
        fill="none"
        stroke={c.danger}
        strokeWidth={2.5}
        strokeDasharray={1}
        pathLength={1}
        strokeDashoffset={1 - prog(frame, f(2.8), f(3.4))}
      />
      <text x={880} y={104} fill={c.danger} fontFamily={theme.fonts.mono} fontWeight={700} fontSize={26} letterSpacing={3} opacity={prog(frame, f(3.2), f(3.6))} style={{ filter: `drop-shadow(0 0 8px ${c.danger})` }}>
        COAL BUNKER #6
      </text>
    </svg>
  );
};

const HeatMap: React.FC<{ amount: number }> = ({ amount }) => {
  const frame = useCurrentFrame();
  const cols = 16;
  const rows = 10;
  const cell = 22;
  return (
    <div style={{ display: "grid", gridTemplateColumns: `repeat(${cols}, ${cell}px)`, gap: 3 }}>
      {Array.from({ length: cols * rows }, (_, i) => {
        const cx = i % cols;
        const cy = Math.floor(i / cols);
        const d = Math.hypot((cx - cols * 0.6) / cols, (cy - rows * 0.68) / rows);
        const v = clamp01((1.15 - d * 2.7) * amount + Math.sin(frame / 12 + cx * 0.7 + cy * 1.3) * 0.07 * amount);
        return (
          <div
            key={i}
            style={{
              width: cell,
              height: cell,
              borderRadius: 3,
              background: interpolateColors(v, [0, 0.5, 1], ["#0a3a4a", theme.colors.warn, theme.colors.danger]),
              opacity: 0.35 + 0.65 * Math.max(0.25, v),
            }}
          />
        );
      })}
    </div>
  );
};

const Newspaper: React.FC = () => {
  const frame = useCurrentFrame();
  const flicker = 0.92 + 0.08 * Math.sin(frame / 6);
  const bar = (w: string, k: number) => (
    <div key={k} style={{ height: 8, width: w, background: "#3a352a", opacity: 0.55, marginTop: 9 }} />
  );
  return (
    <div
      style={{
        width: 560,
        padding: "16px 26px 20px",
        background: "linear-gradient(135deg, #d8cfb4, #c4b890)",
        color: "#1b1a17",
        fontFamily: theme.fonts.serif,
        boxShadow: `0 20px 60px #000, 0 0 40px ${theme.colors.danger}44`,
        opacity: flicker,
      }}
    >
      <div style={{ textAlign: "center", fontWeight: 700, fontSize: 30, letterSpacing: 3, borderBottom: "3px double #1b1a17", paddingBottom: 6 }}>
        THE ATLANTIC HERALD
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, margin: "6px 0 10px" }}>
        <span>LATE EDITION</span>
        <span>APRIL 1912</span>
      </div>
      <div style={{ fontWeight: 900, fontSize: 38, lineHeight: 1.05 }}>FIRE REPORTED IN THE BUNKERS?</div>
      {[100, 92, 96, 70].map((w, k) => bar(`${w}%`, k))}
    </div>
  );
};

export const Scene2: React.FC = () => {
  const frame = useCurrentFrame();
  const zoom = interpolate(frame, [f(0.4), f(2.1)], [1, 3.6], {
    easing: theme.ease.inOut,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const shipFade = 1 - prog(frame, f(1.4), f(2.2));
  const cutIn = prog(frame, f(1.7), f(2.5), theme.ease.out);
  const heat = prog(frame, f(2.4), f(6.0), theme.ease.out);
  const temp = prog(frame, f(3.6), f(5.4), theme.ease.out);
  return (
    <SceneShell shakes={[f(5.4)]} zoom={[1.02, 1.07]}>
      <Sfx name="whoosh" at={f(0.2)} volume={0.35} />
      <Sfx name="whoosh" at={f(1.6)} volume={0.3} />
      <Sfx name="ping" at={f(3.3)} volume={0.35} />
      <Sfx name="impact" at={f(5.35)} volume={0.55} />
      <Sfx name="pop" at={f(6.0)} volume={0.35} />

      {/* left: hull zoom -> cutaway */}
      <div style={{ position: "absolute", left: 110, top: 128, width: 860, height: 560, overflow: "hidden", border: `2px solid ${theme.colors.primary}55`, borderRadius: 14, background: "rgba(2,20,31,0.45)" }}>
        <div style={{ position: "absolute", left: 20, top: 150, opacity: shipFade, transformOrigin: "72% 82%", transform: `scale(${zoom})` }}>
          <ShipSvg width={820} />
        </div>
        <div style={{ position: "absolute", left: 0, top: 80, opacity: cutIn, transform: `scale(${interpolate(cutIn, [0, 1], [1.25, 1])})` }}>
          <Cutaway />
        </div>
      </div>

      {/* right column */}
      <div style={{ position: "absolute", left: 1010, top: 128 }}>
        <Entrance delay={f(2.8)} x={60} y={0}>
          <div style={{ padding: 16, border: `2px solid ${theme.colors.warn}88`, borderRadius: 12, background: "rgba(2,20,31,0.6)", boxShadow: `0 0 26px ${theme.colors.warn}33` }}>
            <div style={{ fontFamily: theme.fonts.mono, fontWeight: 700, fontSize: 16, letterSpacing: "0.16em", color: theme.colors.warn, marginBottom: 10 }}>
              THERMAL MAP // BUNKER #6
            </div>
            <HeatMap amount={heat} />
          </div>
        </Entrance>
      </div>
      <div style={{ position: "absolute", left: 1490, top: 120 }}>
        <Entrance delay={f(3.4)} y={-30}>
          <RingGauge
            value={temp}
            size={260}
            color={temp > 0.7 ? theme.colors.danger : theme.colors.warn}
            label="EST. TEMP"
            readout={`${Math.round(temp * 1000)}°C`}
          />
        </Entrance>
        <Entrance delay={f(4.2)} y={20}>
          <div style={{ marginTop: 10, textAlign: "center", fontFamily: theme.fonts.mono, fontWeight: 700, color: theme.colors.text, fontSize: 22, letterSpacing: "0.12em" }}>
            BURNING: <Counter to={10} delay={f(4.2)} style={{ color: theme.colors.danger, textShadow: `0 0 12px ${theme.colors.danger}` }} /> DAYS
          </div>
        </Entrance>
      </div>
      <div style={{ position: "absolute", left: 1090, top: 474, transform: "rotate(-3deg)" }}>
        <Entrance delay={f(6.0)} y={80}>
          <Newspaper />
        </Entrance>
      </div>

      <NeonCaption text={TEXT} delay={f(1.2)} size={50} width={1640} color={theme.colors.warn} bottom={74} />
    </SceneShell>
  );
};
