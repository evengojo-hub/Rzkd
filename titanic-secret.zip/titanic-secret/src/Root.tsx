import React from "react";
import { CalculateMetadataFunction, Composition, staticFile } from "remotion";
import { getAudioDurationInSeconds } from "@remotion/media-utils";
import { MainComposition, MainProps } from "./Composition";
import { FPS, HEIGHT, WIDTH } from "./theme";

/** Drop your voiceover at public/voice.mp3 — the video length is read from it at render time. */
const AUDIO_SRC = "voice.mp3";

const calculateMetadata: CalculateMetadataFunction<MainProps> = async ({ props }) => {
  const seconds = await getAudioDurationInSeconds(staticFile(props.audioSrc));
  return {
    durationInFrames: Math.max(1, Math.ceil(seconds * FPS)),
  };
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Main"
    component={MainComposition}
    durationInFrames={FPS * 47} // placeholder only, overwritten by calculateMetadata
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
    defaultProps={{ audioSrc: AUDIO_SRC }}
    calculateMetadata={calculateMetadata}
  />
);
