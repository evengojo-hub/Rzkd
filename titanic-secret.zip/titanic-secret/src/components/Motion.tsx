import React from "react";
import {
  AbsoluteFill,
  Audio,
  Sequence,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { theme } from "../theme";
import { STAMP_LAND, f } from "../timeline";

export const useExit = (seconds = 0.2) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  return interpolate(frame, [durationInFrames - f(seconds), durationInFrames - 1], [0, 1], {
    easing: theme.ease.in,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

/** Local 0..1 progress with ease between two frames */
export const prog = (frame: number, from: number, to: number, easing = theme.ease.inOut) =>
  interpolate(frame, [from, to], [0, 1], {
    easing,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

export const Sfx: React.FC<{ name: string; at: number; volume?: number }> = ({
  name,
  at,
  volume = 0.5,
}) => (
  <Sequence from={Math.max(0, at)} durationInFrames={f(3)} layout="none">
    <Audio src={staticFile(`sfx/${name}.wav`)} volume={volume} />
  </Sequence>
);

export const Entrance: React.FC<{
  delay?: number;
  y?: number;
  x?: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ delay = 0, y = 40, x = 0, children, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  const idle = Math.sin(frame / 38 + delay) * 3 * p;
  return (
    <div
      style={{
        opacity: Math.min(1, p),
        transform: `translate(${interpolate(p, [0, 1], [x, 0])}px, ${
          interpolate(p, [0, 1], [y, 0]) + idle
        }px) scale(${interpolate(p, [0, 1], [0.94, 1])})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

export const WordReveal: React.FC<{
  text: string;
  delay?: number;
  per?: number;
  style?: React.CSSProperties;
}> = ({ text, delay = 0, per = 5, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "center",
        columnGap: 18,
        rowGap: 4,
        ...style,
      }}
    >
      {text.split(" ").map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: Math.min(1, p),
              transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(
                p,
                [0, 1],
                [0.9, 1]
              )})`,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

export const Counter: React.FC<{
  to: number;
  from?: number;
  delay?: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  style?: React.CSSProperties;
}> = ({ to, from = 0, delay = 0, decimals = 0, prefix = "", suffix = "", style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: { damping: 30, stiffness: 60 } });
  const v = interpolate(p, [0, 1], [from, to]);
  const text = decimals > 0 ? v.toFixed(decimals) : Math.round(v).toLocaleString("en-US");
  return (
    <span style={{ fontVariantNumeric: "tabular-nums", ...style }}>
      {prefix}
      {text}
      {suffix}
    </span>
  );
};

export const NeonCaption: React.FC<{
  text: string;
  delay?: number;
  color?: string;
  size?: number;
  width?: number;
  bottom?: number;
}> = ({ text, delay = 0, color = theme.colors.primary, size = 54, width = 1560, bottom = 74 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  const pulse = 0.75 + 0.25 * Math.sin(frame / 18);
  return (
    <div
      style={{
        position: "absolute",
        left: "50%",
        bottom,
        width,
        padding: "26px 48px",
        textAlign: "center",
        border: `3px solid ${color}`,
        borderRadius: 18,
        background: "rgba(2,7,13,0.74)",
        boxShadow: `0 0 ${18 * pulse}px ${color}, 0 0 ${64 * pulse}px ${color}66, inset 0 0 34px ${color}33`,
        opacity: Math.min(1, p),
        transform: `translateX(-50%) translateY(${interpolate(p, [0, 1], [50, 0])}px) scaleX(${interpolate(
          p,
          [0, 1],
          [0.82, 1]
        )})`,
        fontFamily: theme.fonts.bn,
        fontWeight: 700,
        fontSize: size,
        lineHeight: 1.55,
        color: theme.colors.text,
        textShadow: `0 0 12px ${color}, 0 0 34px ${color}88`,
      }}
    >
      <WordReveal text={text} delay={delay + 6} per={4} />
    </div>
  );
};

export const Stamp: React.FC<{
  text: string;
  color: string;
  at: number;
  x?: string;
  y?: string;
  rotate?: number;
  size?: number;
}> = ({ text, color, at, x = "50%", y = "50%", rotate = -7, size = 120 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const dt = frame - at;
  const p = spring({ frame: dt, fps, config: theme.spring.stamp });
  const scale = interpolate(p, [0, 1], [3.4, 1]);
  const op = interpolate(dt, [0, 4], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const ring = interpolate(dt, [STAMP_LAND, STAMP_LAND + f(0.5)], [0, 1], {
    easing: theme.ease.out,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const flash = interpolate(dt, [STAMP_LAND, STAMP_LAND + 3, STAMP_LAND + f(0.25)], [0, 0.5, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const breathe = dt > f(0.6) ? 1 + Math.sin(frame / 24) * 0.012 : 1;
  return (
    <>
      <AbsoluteFill style={{ background: "#fff", opacity: flash * 0.35, pointerEvents: "none" }} />
      <div
        style={{
          position: "absolute",
          left: x,
          top: y,
          width: 900,
          height: 900,
          marginLeft: -450,
          marginTop: -450,
          borderRadius: "50%",
          border: `4px solid ${color}`,
          opacity: dt >= STAMP_LAND ? (1 - ring) * 0.8 : 0,
          transform: `scale(${0.2 + ring * 1.6})`,
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "absolute",
          left: x,
          top: y,
          opacity: op,
          transform: `translate(-50%, -50%) rotate(${rotate}deg) scale(${scale * breathe})`,
          padding: "6px 46px 14px",
          border: `10px solid ${color}`,
          outline: `3px solid ${color}`,
          outlineOffset: 8,
          borderRadius: 10,
          color,
          background: "rgba(2,7,13,0.55)",
          fontFamily: theme.fonts.bn,
          fontWeight: 900,
          fontSize: size,
          letterSpacing: "0.06em",
          whiteSpace: "nowrap",
          textShadow: `0 0 18px ${color}, 0 0 54px ${color}`,
          boxShadow: `0 0 28px ${color}, 0 0 90px ${color}66, inset 0 0 34px ${color}44`,
        }}
      >
        {text}
      </div>
    </>
  );
};

/** Subtle camera drift + spring-physics screen shake + in/out fade for a scene */
export const SceneShell: React.FC<{
  children: React.ReactNode;
  shakes?: number[];
  zoom?: [number, number];
}> = ({ children, shakes = [], zoom = [1.03, 1.09] }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const exit = useExit(0.2);
  const enter = prog(frame, 0, f(0.2), theme.ease.out);
  const z = interpolate(frame, [0, durationInFrames], zoom, {
    easing: theme.ease.inOut,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  let sx = 0;
  let sy = 0;
  let sr = 0;
  for (const s of shakes) {
    const dt = frame - s;
    if (dt >= 0 && dt < f(0.45)) {
      const a = Math.exp(-dt / f(0.1));
      sx += Math.sin(dt * 2.9) * 20 * a;
      sy += Math.cos(dt * 3.7) * 15 * a;
      sr += Math.sin(dt * 2.1) * 0.7 * a;
    }
  }
  const dx = Math.sin(frame / 90) * 14 + sx;
  const dy = Math.cos(frame / 110) * 9 + sy;
  return (
    <AbsoluteFill
      style={{
        opacity: enter * (1 - exit),
        transform: `translate(${dx}px, ${dy}px) rotate(${sr}deg) scale(${z + exit * 0.03})`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};
