import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { FPS, getSceneFrames, theme } from "../theme";
import { depthAt } from "../timeline";

const LABELS = ["BLUEPRINT SCAN", "HULL BREACH ANALYSIS", "COLLISION TRACE", "CASE FILE 1912", "DEEP DIVE"];

const pad = (n: number, l = 2) => String(Math.floor(n)).padStart(l, "0");

const Corner: React.FC<{ pos: "tl" | "tr" | "bl" | "br" }> = ({ pos }) => {
  const s = 64;
  const c = theme.colors.primary;
  const base: React.CSSProperties = {
    position: "absolute",
    width: s,
    height: s,
    borderColor: c,
    borderStyle: "solid",
    borderWidth: 0,
    filter: `drop-shadow(0 0 6px ${c})`,
  };
  const m = 26;
  if (pos === "tl") return <div style={{ ...base, left: m, top: m, borderLeftWidth: 3, borderTopWidth: 3 }} />;
  if (pos === "tr") return <div style={{ ...base, right: m, top: m, borderRightWidth: 3, borderTopWidth: 3 }} />;
  if (pos === "bl") return <div style={{ ...base, left: m, bottom: m, borderLeftWidth: 3, borderBottomWidth: 3 }} />;
  return <div style={{ ...base, right: m, bottom: m, borderRightWidth: 3, borderBottomWidth: 3 }} />;
};

/** LAYER 4 — broadcast telemetry HUD (global frame) */
export const HUD: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames: TOTAL_FRAMES } = useVideoConfig();
  const sceneFrames = getSceneFrames(TOTAL_FRAMES);
  const enter = spring({ frame: frame - 6, fps, config: theme.spring.smooth });
  const idx = Math.max(
    0,
    sceneFrames.findIndex((s, i) => frame >= s.from && (i === sceneFrames.length - 1 || frame < sceneFrames[i + 1].from))
  );
  const sec = frame / FPS;
  const tc = `${pad(sec / 60)}:${pad(sec % 60)}:${pad(frame % FPS)}`;
  const blink = Math.sin(frame / 9) > 0 ? 1 : 0.25;
  const depth = depthAt(frame, TOTAL_FRAMES);
  const progress = frame / TOTAL_FRAMES;
  const mono: React.CSSProperties = {
    fontFamily: theme.fonts.mono,
    fontWeight: 700,
    letterSpacing: "0.14em",
    color: theme.colors.text,
    fontSize: 20,
    textShadow: `0 0 10px ${theme.colors.primary}`,
  };
  return (
    <AbsoluteFill
      style={{
        opacity: Math.min(1, enter),
        transform: `translateY(${interpolate(enter, [0, 1], [-18, 0])}px)`,
        pointerEvents: "none",
      }}
    >
      <Corner pos="tl" />
      <Corner pos="tr" />
      <Corner pos="bl" />
      <Corner pos="br" />

      {/* top-left */}
      <div style={{ position: "absolute", left: 110, top: 34, display: "flex", alignItems: "center", gap: 14 }}>
        <div
          style={{
            width: 16,
            height: 16,
            borderRadius: "50%",
            background: theme.colors.danger,
            boxShadow: `0 0 14px ${theme.colors.danger}`,
            opacity: blink,
          }}
        />
        <span style={mono}>REC // ARCHIVE 1912-RMS-TITANIC</span>
      </div>

      {/* top-center */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 34, textAlign: "center" }}>
        <span style={{ ...mono, color: theme.colors.warn, textShadow: `0 0 12px ${theme.colors.warn}` }}>
          [ {pad(idx + 1)} / 05 ] {LABELS[idx]}
        </span>
      </div>

      {/* top-right */}
      <div style={{ position: "absolute", right: 110, top: 34, display: "flex", gap: 22 }}>
        <span style={mono}>{tc}</span>
        <span style={{ ...mono, color: theme.colors.textDim, textShadow: "none" }}>{FPS}FPS</span>
      </div>

      {/* bottom-left telemetry */}
      <div style={{ position: "absolute", left: 110, bottom: 44, display: "flex", flexDirection: "column", gap: 6 }}>
        <span style={{ ...mono, fontSize: 17, color: theme.colors.textDim, textShadow: "none" }}>
          N 41°43′32″ &nbsp; W 49°56′49″
        </span>
        <span style={{ ...mono, fontSize: 17 }}>
          DEPTH {Math.round(depth).toLocaleString("en-US")} M &nbsp;|&nbsp; PRESS{" "}
          {(1 + depth / 10).toFixed(0)} ATM
        </span>
      </div>

      {/* bottom-right signal bars */}
      <div style={{ position: "absolute", right: 110, bottom: 44, display: "flex", alignItems: "flex-end", gap: 5 }}>
        <span style={{ ...mono, fontSize: 17, marginRight: 14, color: theme.colors.textDim, textShadow: "none" }}>
          SIGNAL
        </span>
        {Array.from({ length: 18 }, (_, i) => {
          const h = 8 + Math.abs(Math.sin(frame / 7 + i * 0.9) * Math.cos(frame / 23 + i)) * 30;
          return (
            <div
              key={i}
              style={{
                width: 6,
                height: h,
                background: i > 13 ? theme.colors.warn : theme.colors.primary,
                boxShadow: `0 0 8px ${i > 13 ? theme.colors.warn : theme.colors.primary}`,
              }}
            />
          );
        })}
      </div>

      {/* progress rail */}
      <div style={{ position: "absolute", left: 110, right: 110, bottom: 22, height: 3, background: "#ffffff1f" }}>
        <div
          style={{
            width: `${progress * 100}%`,
            height: "100%",
            background: theme.colors.primary,
            boxShadow: `0 0 12px ${theme.colors.primary}`,
          }}
        />
      </div>
    </AbsoluteFill>
  );
};
