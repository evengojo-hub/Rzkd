import { Config } from "@remotion/cli/config";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

/** Chromium flags required to launch inside GitHub Codespaces / Docker / any container or root Linux. */
const CHROME_ARGS = ["--no-sandbox", "--disable-setuid-sandbox"];

const isExecutable = (p: string) => {
  try {
    fs.accessSync(p, fs.constants.X_OK);
    return fs.statSync(p).isFile();
  } catch {
    return false;
  }
};

const walk = (dir: string, depth: number): string | null => {
  if (depth < 0 || !fs.existsSync(dir)) return null;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isFile() && (entry.name === "chrome-headless-shell" || entry.name === "chrome") && isExecutable(full)) {
      return full;
    }
  }
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      const hit = walk(path.join(dir, entry.name), depth - 1);
      if (hit) return hit;
    }
  }
  return null;
};

const findChrome = (): string | null => {
  const fromEnv = process.env.REMOTION_CHROME_BIN;
  if (fromEnv && isExecutable(fromEnv)) return fromEnv;
  return walk(path.join(process.cwd(), "node_modules", ".remotion"), 6);
};

if (process.platform === "linux") {
  const real = findChrome();
  if (real) {
    const wrapper = path.join(os.tmpdir(), "remotion-chrome-nosandbox.sh");
    fs.writeFileSync(wrapper, `#!/bin/sh\nexec "${real}" ${CHROME_ARGS.join(" ")} "$@"\n`, { mode: 0o755 });
    fs.chmodSync(wrapper, 0o755);
    Config.setBrowserExecutable(wrapper);
  } else {
    console.warn("[remotion.config] Chrome not downloaded yet. Run: npx remotion browser ensure  (then retry)");
  }
}

Config.setVideoImageFormat("png");
Config.setOverwriteOutput(true);
Config.setCodec("h264");
Config.setCrf(17);
Config.setConcurrency(2);
