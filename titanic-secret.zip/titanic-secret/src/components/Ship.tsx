import React from "react";
import { theme } from "../theme";

const FUNNELS = [380, 500, 620, 740];
const clamp = (v: number) => Math.min(1, Math.max(0, v));

const draw = (progress: number, start: number, span: number) => 1 - clamp((progress - start) / span);

/** Side-profile blueprint of the ship (viewBox 0 0 1200 330). Renders a <g> — wrap in <svg>. */
export const ShipGroup: React.FC<{
  progress?: number;
  color?: string;
  strokeWidth?: number;
  fill?: string;
}> = ({ progress = 1, color = theme.colors.primary, strokeWidth = 3, fill = "none" }) => {
  const common = {
    fill: "none",
    stroke: color,
    strokeWidth,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    pathLength: 1,
    strokeDasharray: 1,
  };
  const windows = progress > 0.72 ? clamp((progress - 0.72) / 0.2) : 0;
  return (
    <g>
      <path
        d="M62 168 L84 258 Q96 288 170 288 L985 288 Q1075 276 1138 150 Q600 186 62 168 Z"
        {...common}
        fill={fill}
        strokeDashoffset={draw(progress, 0, 0.4)}
      />
      <path d="M215 172 L215 126 L965 126 L965 176" {...common} strokeDashoffset={draw(progress, 0.25, 0.25)} />
      <path d="M250 126 L250 100 L930 100 L930 126" {...common} strokeDashoffset={draw(progress, 0.32, 0.22)} />
      {FUNNELS.map((x, i) => (
        <g key={x}>
          <path
            d={`M${x - 28} 100 L${x - 24} 22 L${x + 24} 22 L${x + 28} 100`}
            {...common}
            strokeDashoffset={draw(progress, 0.4 + i * 0.07, 0.2)}
          />
          <path
            d={`M${x - 25} 38 L${x + 25} 38`}
            {...common}
            strokeDashoffset={draw(progress, 0.55 + i * 0.07, 0.15)}
          />
        </g>
      ))}
      <path d="M300 126 L300 38 M1010 150 L1010 48" {...common} strokeDashoffset={draw(progress, 0.6, 0.2)} />
      <path
        d="M300 38 L120 168 M300 38 L215 172 M1010 48 L1130 152 M1010 48 L965 126"
        {...common}
        strokeWidth={strokeWidth * 0.5}
        strokeDashoffset={draw(progress, 0.68, 0.2)}
      />
      <path
        d="M70 262 L1100 262"
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth * 0.5}
        strokeDasharray="14 10"
        opacity={clamp((progress - 0.5) / 0.2) * 0.8}
      />
      <g opacity={windows}>
        {Array.from({ length: 30 }, (_, i) => (
          <circle key={`a${i}`} cx={235 + i * 24} cy={148} r={3.4} fill={color} />
        ))}
        {Array.from({ length: 28 }, (_, i) => (
          <circle key={`b${i}`} cx={270 + i * 24} cy={113} r={3} fill={color} opacity={0.7} />
        ))}
        {Array.from({ length: 36 }, (_, i) => (
          <rect key={`c${i}`} x={100 + i * 26} y={205} width={14} height={7} fill="none" stroke={color} strokeWidth={1.5} />
        ))}
      </g>
    </g>
  );
};

export const ShipSvg: React.FC<{
  progress?: number;
  color?: string;
  width?: number;
  fill?: string;
  glow?: number;
  style?: React.CSSProperties;
}> = ({ progress = 1, color = theme.colors.primary, width = 1300, fill = "none", glow = 10, style }) => (
  <svg
    viewBox="0 0 1200 330"
    width={width}
    height={(width * 330) / 1200}
    style={{ filter: `drop-shadow(0 0 ${glow}px ${color})`, overflow: "visible", ...style }}
  >
    <ShipGroup progress={progress} color={color} fill={fill} />
  </svg>
);

/** Reusable neon ring gauge (0..1 value) */
export const RingGauge: React.FC<{
  value: number;
  size?: number;
  color?: string;
  label: string;
  readout: string;
}> = ({ value, size = 220, color = theme.colors.primary, label, readout }) => {
  const r = size / 2 - 16;
  const c = 2 * Math.PI * r;
  const sweep = 0.75;
  return (
    <div style={{ width: size, textAlign: "center" }}>
      <svg width={size} height={size} style={{ filter: `drop-shadow(0 0 8px ${color})` }}>
        <g transform={`rotate(135 ${size / 2} ${size / 2})`}>
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            stroke={`${color}33`}
            strokeWidth={12}
            strokeDasharray={`${c * sweep} ${c}`}
            strokeLinecap="round"
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            stroke={color}
            strokeWidth={12}
            strokeDasharray={`${c * sweep * Math.min(1, Math.max(0, value))} ${c}`}
            strokeLinecap="round"
          />
        </g>
        <text
          x={size / 2}
          y={size / 2 + 12}
          textAnchor="middle"
          fill={theme.colors.text}
          fontFamily={theme.fonts.mono}
          fontWeight={700}
          fontSize={size * 0.19}
        >
          {readout}
        </text>
      </svg>
      <div
        style={{
          marginTop: -34,
          fontFamily: theme.fonts.mono,
          fontWeight: 700,
          fontSize: 17,
          letterSpacing: "0.14em",
          color,
          textShadow: `0 0 10px ${color}`,
        }}
      >
        {label}
      </div>
    </div>
  );
};
