import { interpolate } from "remotion";
import { FPS, getSceneFrames, theme } from "./theme";

/** seconds -> frames, always derived from the project fps */
export const f = (seconds: number) => Math.round(seconds * FPS);

/** Frames of impact delay for the stamp spring (visual "landing") */
export const STAMP_LAND = f(0.14);

/** Depth in metres from a frame local to the final scene. 0 -> 3,800 m. */
export const depthLocal = (localFrame: number) =>
  interpolate(localFrame, [f(0.3), f(3.0)], [0, 3800], {
    easing: theme.ease.inOut,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

/** Global depth (0 until the final scene starts). */
export const depthAt = (globalFrame: number, totalFrames: number) =>
  depthLocal(globalFrame - getSceneFrames(totalFrames)[4].from);

/** Glitch intensity 0..1 around each scene cut */
export const glitchAmount = (frame: number, cuts: number[]) => {
  const half = f(0.12);
  let g = 0;
  for (const c of cuts) {
    const dt = frame - (c - half);
    if (dt >= 0 && dt <= half * 2) {
      g = Math.max(g, Math.sin((Math.PI * dt) / (half * 2)));
    }
  }
  return g;
};
