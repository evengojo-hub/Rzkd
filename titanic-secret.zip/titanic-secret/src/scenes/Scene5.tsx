import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { Entrance, NeonCaption, SceneShell, Sfx, prog } from "../components/Motion";
import { RingGauge, ShipGroup } from "../components/Ship";
import { depthLocal, f } from "../timeline";
import { theme } from "../theme";

const TEXT = "ইতিহাসের আরও গোপন ফাইল খুলতে এখনই যুক্ত থাকুন!";
const SONAR_AT = f(3.0);

const Ruler: React.FC<{ depth: number }> = ({ depth }) => {
  const offset = (depth * 0.5) % 100;
  return (
    <div style={{ position: "absolute", left: 120, top: 120, width: 150, height: 600, overflow: "hidden", borderLeft: `3px solid ${theme.colors.primary}` }}>
      {Array.from({ length: 8 }, (_, i) => {
        const y = i * 100 - 100 + offset;
        const major = (Math.round((depth * 0.5 - offset) / 100) + (7 - i)) % 2 === 0;
        return (
          <div key={i} style={{ position: "absolute", left: 0, top: y, width: major ? 70 : 40, height: 3, background: theme.colors.primary, boxShadow: `0 0 8px ${theme.colors.primary}` }} />
        );
      })}
      <div style={{ position: "absolute", left: 0, top: 290, width: 150, height: 4, background: theme.colors.danger, boxShadow: `0 0 14px ${theme.colors.danger}` }} />
    </div>
  );
};

const Wreck: React.FC<{ reveal: number }> = ({ reveal }) => {
  const frame = useCurrentFrame();
  const r = reveal * 1100;
  const ring = reveal > 0 && reveal < 1;
  return (
    <div style={{ position: "relative", width: 1100, height: 560 }}>
      <svg viewBox="0 0 1100 560" width={1100} height={560} style={{ position: "absolute", inset: 0, overflow: "visible" }}>
        <defs>
          <clipPath id="sonarClip">
            <circle cx={550} cy={403} r={r} />
          </clipPath>
        </defs>
        <g clipPath="url(#sonarClip)" style={{ filter: `drop-shadow(0 0 10px ${theme.colors.primary})` }}>
          {/* seafloor */}
          <path d="M0 470 Q180 440 340 468 T700 460 T1100 470 L1100 560 L0 560 Z" fill={`${theme.colors.primary}14`} stroke={theme.colors.primary} strokeWidth={2.5} />
          {/* stern section, tilted */}
          <g transform="translate(-40 150) scale(0.62) rotate(-8 600 165)">
            <g transform="translate(0 0)">
              <ShipGroup color={theme.colors.primary} fill={`${theme.colors.primary}12`} />
            </g>
          </g>
          {/* bow section upright-ish, further right */}
          <g transform="translate(470 175) scale(0.55) rotate(12 600 165)">
            <ShipGroup color={theme.colors.primary} fill={`${theme.colors.primary}12`} />
          </g>
        </g>
        {ring && (
          <circle cx={550} cy={403} r={r} fill="none" stroke={theme.colors.primary} strokeWidth={4} opacity={0.9} style={{ filter: `drop-shadow(0 0 14px ${theme.colors.primary})` }} />
        )}
        {[0.33, 0.66].map((k) => {
          const rr = ((frame / f(1.6) + k) % 1) * 900;
          return (
            <circle key={k} cx={550} cy={403} r={rr} fill="none" stroke={theme.colors.primary} strokeWidth={1.5} opacity={reveal > 0 ? (1 - rr / 900) * 0.5 : 0} />
          );
        })}
      </svg>
    </div>
  );
};

const Bell: React.FC<{ rot: number }> = ({ rot }) => (
  <svg width={44} height={44} viewBox="0 0 24 24" style={{ transform: `rotate(${rot}deg)`, transformOrigin: "50% 10%" }}>
    <path d="M12 2c-3.3 0-6 2.7-6 6v4l-2 3v1h16v-1l-2-3V8c0-3.3-2.7-6-6-6zm-2 17a2 2 0 0 0 4 0z" fill="#fff" />
  </svg>
);

const Cta: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const at = durationInFrames - f(2.0);
  const p = spring({ frame: frame - at, fps, config: theme.spring.bouncy });
  const pulse = 1 + Math.sin(frame / 10) * 0.025;
  const bell = Math.sin(frame / 3.2) * 16 * (Math.sin(frame / 22) > 0.3 ? 1 : 0.2);
  return (
    <div
      style={{
        position: "absolute",
        left: "50%",
        top: 612,
        display: "flex",
        alignItems: "center",
        gap: 28,
        opacity: Math.min(1, p),
        transform: `translateX(-50%) scale(${interpolate(p, [0, 1], [0.4, 1]) * pulse})`,
      }}
    >
      <div
        style={{
          width: 132,
          height: 92,
          borderRadius: 24,
          background: theme.colors.danger,
          boxShadow: `0 0 34px ${theme.colors.danger}, 0 0 90px ${theme.colors.danger}88`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div style={{ width: 0, height: 0, marginLeft: 8, borderTop: "20px solid transparent", borderBottom: "20px solid transparent", borderLeft: "34px solid #fff" }} />
      </div>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 18,
          padding: "14px 40px",
          borderRadius: 60,
          border: `3px solid ${theme.colors.danger}`,
          background: "rgba(40,4,6,0.7)",
          boxShadow: `0 0 26px ${theme.colors.danger}66`,
          fontFamily: theme.fonts.bn,
          fontWeight: 900,
          fontSize: 50,
          lineHeight: 1.5,
          color: theme.colors.text,
          textShadow: `0 0 14px ${theme.colors.danger}`,
        }}
      >
        সাবস্ক্রাইব করুন
        <Bell rot={bell} />
      </div>
    </div>
  );
};

export const Scene5: React.FC = () => {
  const frame = useCurrentFrame();
  const depth = depthLocal(frame);
  const reveal = prog(frame, SONAR_AT, SONAR_AT + f(1.6), theme.ease.out);
  const pressure = 1 + depth / 10;
  return (
    <SceneShell shakes={[SONAR_AT + f(0.9)]} zoom={[1.02, 1.06]}>
      <Sfx name="whoosh" at={f(0.1)} volume={0.35} />
      <Sfx name="ping" at={SONAR_AT - 2} volume={0.5} />
      <Sfx name="ping" at={SONAR_AT + f(1.4)} volume={0.3} />
      <Sfx name="pop" at={f(4.2)} volume={0.45} />

      <Ruler depth={depth} />
      <div style={{ position: "absolute", left: 300, top: 150 }}>
        <Entrance delay={f(0.2)} x={-40} y={0}>
          <div style={{ fontFamily: theme.fonts.mono, fontWeight: 700, letterSpacing: "0.08em", color: theme.colors.text, textShadow: `0 0 20px ${theme.colors.primary}` }}>
            <div style={{ fontSize: 24, color: theme.colors.textDim }}>DEPTH</div>
            <div style={{ fontSize: 96, color: theme.colors.primary }}>
              {Math.round(depth).toLocaleString("en-US")} M
            </div>
          </div>
        </Entrance>
      </div>
      <div style={{ position: "absolute", right: 150, top: 120 }}>
        <Entrance delay={f(0.6)} y={-30}>
          <RingGauge
            value={Math.min(1, pressure / 381)}
            size={250}
            color={theme.colors.warn}
            label="PRESSURE (ATM)"
            readout={Math.round(pressure).toString()}
          />
        </Entrance>
      </div>
      <div style={{ position: "absolute", left: 410, top: 130 }}>
        <Wreck reveal={reveal} />
      </div>
      {reveal > 0.5 && (
        <div
          style={{
            position: "absolute",
            left: 760,
            top: 560,
            fontFamily: theme.fonts.mono,
            fontWeight: 700,
            fontSize: 26,
            letterSpacing: "0.14em",
            color: theme.colors.warn,
            textShadow: `0 0 12px ${theme.colors.warn}`,
          }}
        >
          SONAR CONTACT // WRECK CONFIRMED
        </div>
      )}
      <AbsoluteFill>
        <Cta />
      </AbsoluteFill>
      <NeonCaption text={TEXT} delay={f(0.8)} size={52} width={1500} color={theme.colors.primary} bottom={72} />
    </SceneShell>
  );
};
