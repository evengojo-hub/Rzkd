import React from "react";
import { AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { Entrance, NeonCaption, SceneShell, Sfx, Stamp, prog } from "../components/Motion";
import { ShipSvg } from "../components/Ship";
import { STAMP_LAND, f } from "../timeline";
import { theme } from "../theme";

const TEXT = "ঠিক সেই আগুনে দুর্বল হওয়া জায়গাতেই আঘাত হানে দানবীয় বরফখণ্ড...";
const IMPACT = f(6.0);
const SNAP = f(8.4);
const STAMP_AT = f(6.15);
const SHIP_W = 900;
const SHIP_H = (SHIP_W * 330) / 1200;
const SPLIT = 63; // % of ship width where the hull breaks (over the weakened bunker zone)

const CRACK = "M756 288 L744 262 L768 236 L746 208 L766 182 L750 150";

/* ---------------- Radar ---------------- */
const Radar: React.FC = () => {
  const frame = useCurrentFrame();
  const size = 600;
  const R = size / 2;
  const range = interpolate(frame, [f(0.9), f(6.0)], [1, 0.07], {
    easing: theme.ease.inOut,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const ang = (frame * 2) % 360;
  const bx = R + Math.cos(-0.7) * range * (R - 20);
  const by = R + Math.sin(-0.7) * range * (R - 20);
  const hot = range < 0.35;
  const col = hot ? theme.colors.danger : theme.colors.warn;
  const blipPulse = (frame % f(1)) / f(1);
  const detect = prog(frame, f(0.9), f(1.3), theme.ease.out);
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: "50%",
          border: `3px solid ${theme.colors.primary}`,
          background: `radial-gradient(circle, ${theme.colors.primary}1a, rgba(2,20,31,0.75) 72%)`,
          boxShadow: `0 0 40px ${theme.colors.primary}55, inset 0 0 60px ${theme.colors.primary}33`,
        }}
      />
      {[0.25, 0.5, 0.75].map((k) => (
        <div
          key={k}
          style={{
            position: "absolute",
            left: R - R * k,
            top: R - R * k,
            width: 2 * R * k,
            height: 2 * R * k,
            borderRadius: "50%",
            border: `1.5px solid ${theme.colors.primary}55`,
          }}
        />
      ))}
      <div style={{ position: "absolute", left: 0, right: 0, top: R, height: 1.5, background: `${theme.colors.primary}55` }} />
      <div style={{ position: "absolute", top: 0, bottom: 0, left: R, width: 1.5, background: `${theme.colors.primary}55` }} />
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: "50%",
          background: `conic-gradient(from 0deg, transparent 0deg, transparent 280deg, ${theme.colors.primary}99 360deg)`,
          transform: `rotate(${ang}deg)`,
          mixBlendMode: "screen",
        }}
      />
      {/* ship at centre */}
      <div
        style={{
          position: "absolute",
          left: R - 9,
          top: R - 9,
          width: 18,
          height: 18,
          background: theme.colors.primary,
          transform: "rotate(45deg)",
          boxShadow: `0 0 18px ${theme.colors.primary}`,
        }}
      />
      {/* iceberg contact */}
      <div style={{ opacity: detect }}>
        <div
          style={{
            position: "absolute",
            left: bx - 12,
            top: by - 12,
            width: 24,
            height: 24,
            borderRadius: "50%",
            background: col,
            boxShadow: `0 0 26px ${col}, 0 0 60px ${col}`,
          }}
        />
        <div
          style={{
            position: "absolute",
            left: bx - 12 - blipPulse * 50,
            top: by - 12 - blipPulse * 50,
            width: 24 + blipPulse * 100,
            height: 24 + blipPulse * 100,
            borderRadius: "50%",
            border: `2px solid ${col}`,
            opacity: 1 - blipPulse,
          }}
        />
        <div
          style={{
            position: "absolute",
            left: bx + 30,
            top: by - 40,
            fontFamily: theme.fonts.mono,
            fontWeight: 700,
            fontSize: 18,
            letterSpacing: "0.12em",
            color: col,
            textShadow: `0 0 10px ${col}`,
          }}
        >
          CONTACT: ICEBERG
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          bottom: -42,
          textAlign: "center",
          fontFamily: theme.fonts.mono,
          fontWeight: 700,
          fontSize: 24,
          letterSpacing: "0.14em",
          color: col,
          textShadow: `0 0 12px ${col}`,
        }}
      >
        RANGE {(range * 0.95).toFixed(2)} NM
      </div>
    </div>
  );
};

/* ---------------- Collision view ---------------- */
const Piece: React.FC<{ side: "stern" | "bow"; snap: number; crack: number; glow: number }> = ({
  side,
  snap,
  crack,
  glow,
}) => {
  const left = side === "stern";
  const clip = left ? `inset(-80px ${100 - SPLIT}% -80px -80px)` : `inset(-80px -80px -80px ${SPLIT}%)`;
  const tx = left ? -54 * snap : 74 * snap;
  const ty = left ? 18 * snap : 80 * snap;
  const rot = left ? 7 * snap : 14 * snap;
  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        top: 0,
        width: SHIP_W,
        height: SHIP_H,
        transformOrigin: `${SPLIT}% 85%`,
        transform: `translate(${tx}px, ${ty}px) rotate(${rot}deg)`,
      }}
    >
      <div style={{ clipPath: clip, WebkitClipPath: clip }}>
        <div style={{ position: "relative", width: SHIP_W, height: SHIP_H }}>
          <ShipSvg width={SHIP_W} progress={1} />
          <svg viewBox="0 0 1200 330" width={SHIP_W} height={SHIP_H} style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
            <circle cx={756} cy={268} r={90} fill={theme.colors.danger} opacity={glow * 0.28} style={{ filter: "blur(18px)" }} />
            <path
              d={CRACK}
              fill="none"
              stroke={theme.colors.danger}
              strokeWidth={6}
              strokeLinecap="round"
              strokeLinejoin="round"
              pathLength={1}
              strokeDasharray={1}
              strokeDashoffset={1 - crack}
              style={{ filter: `drop-shadow(0 0 10px ${theme.colors.danger})` }}
            />
          </svg>
        </div>
      </div>
    </div>
  );
};

const Sparks: React.FC = () => {
  const frame = useCurrentFrame();
  const dt = frame - IMPACT;
  if (dt < 0 || dt > f(1.0)) return null;
  const t = dt / f(1.0);
  return (
    <>
      {Array.from({ length: 22 }, (_, i) => {
        const a = random(`sa${i}`) * Math.PI * 2;
        const v = 90 + random(`sv${i}`) * 260;
        const x = Math.cos(a) * v * t;
        const y = Math.sin(a) * v * t + 220 * t * t;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: 40 + SHIP_W * 0.63 + x,
              top: 232 + SHIP_H * 0.87 + y,
              width: 6,
              height: 6,
              borderRadius: "50%",
              background: i % 2 ? theme.colors.warn : theme.colors.text,
              boxShadow: `0 0 12px ${theme.colors.warn}`,
              opacity: 1 - t,
            }}
          />
        );
      })}
    </>
  );
};

const Iceberg: React.FC<{ x: number }> = ({ x }) => (
  <svg
    viewBox="0 0 360 520"
    width={360}
    height={520}
    style={{
      position: "absolute",
      left: 690 + x,
      top: 190,
      filter: `drop-shadow(0 0 14px ${theme.colors.text})`,
    }}
  >
    <polygon points="30,230 90,120 130,150 200,20 250,110 300,90 350,230" fill="#bfeeff22" stroke={theme.colors.text} strokeWidth={4} strokeLinejoin="round" />
    <polygon points="30,230 350,230 330,380 250,480 160,500 70,400" fill="#00f3ff14" stroke={theme.colors.primary} strokeWidth={3} strokeDasharray="12 8" />
    <polyline points="200,20 190,110 150,230 190,320" fill="none" stroke={theme.colors.text} strokeOpacity={0.5} strokeWidth={2} />
  </svg>
);

const Collision: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const approach = prog(frame, f(1.8), IMPACT, theme.ease.inOut);
  const crack = prog(frame, IMPACT, IMPACT + f(0.8), theme.ease.out);
  const glow = prog(frame, f(1.0), IMPACT, theme.ease.out) * (0.7 + 0.3 * Math.sin(frame / 8));
  const snap = spring({ frame: frame - SNAP, fps, config: theme.spring.smooth });
  const wave = (k: number) =>
    `M0 ${k} ` +
    Array.from({ length: 17 }, (_, i) => `L${i * 62} ${k + Math.sin(frame / 14 + i * 0.9) * 7}`).join(" ") +
    " L980 600 L0 600 Z";
  return (
    <div
      style={{
        position: "relative",
        width: 980,
        height: 600,
        overflow: "hidden",
        border: `2px solid ${theme.colors.primary}55`,
        borderRadius: 14,
        background: "rgba(2,20,31,0.45)",
      }}
    >
      <Iceberg x={(1 - approach) * 380} />
      <div style={{ position: "absolute", left: 40, top: 232 }}>
        <Piece side="stern" snap={snap} crack={crack} glow={glow} />
        <Piece side="bow" snap={snap} crack={crack} glow={glow} />
      </div>
      <svg width={980} height={600} style={{ position: "absolute", left: 0, top: 0 }}>
        <path d={wave(446)} fill={`${theme.colors.primary}1f`} stroke={theme.colors.primary} strokeWidth={2.5} />
      </svg>
      <Sparks />
      {frame > SNAP && (
        <div
          style={{
            position: "absolute",
            left: 24,
            top: 22,
            fontFamily: theme.fonts.mono,
            fontWeight: 700,
            fontSize: 30,
            letterSpacing: "0.16em",
            color: theme.colors.danger,
            textShadow: `0 0 14px ${theme.colors.danger}`,
            opacity: Math.sin(frame / 5) > -0.4 ? 1 : 0.3,
          }}
        >
          HULL SNAP
        </div>
      )}
    </div>
  );
};

export const Scene3: React.FC = () => (
  <SceneShell shakes={[IMPACT, SNAP]} zoom={[1.02, 1.08]}>
    <Sfx name="whoosh" at={f(0.1)} volume={0.35} />
    <Sfx name="ping" at={f(1.0)} volume={0.35} />
    <Sfx name="ping" at={f(3.0)} volume={0.35} />
    <Sfx name="ping" at={f(4.9)} volume={0.45} />
    <Sfx name="impact" at={IMPACT - 2} volume={0.7} />
    <Sfx name="stamp" at={STAMP_AT + STAMP_LAND - 3} volume={0.5} />
    <Sfx name="snap" at={SNAP - 2} volume={0.7} />

    <div style={{ position: "absolute", left: 130, top: 122 }}>
      <Entrance delay={f(0.1)} x={-60} y={0}>
        <Radar />
      </Entrance>
    </div>
    <div style={{ position: "absolute", left: 790, top: 140 }}>
      <Entrance delay={f(0.3)} x={80} y={0}>
        <Collision />
      </Entrance>
    </div>
    <AbsoluteFill>
      <Stamp text="IMPACT 23:40" color={theme.colors.danger} at={STAMP_AT} x="44%" y="24%" rotate={-6} size={78} />
    </AbsoluteFill>
    <NeonCaption text={TEXT} delay={f(0.6)} size={50} width={1640} color={theme.colors.danger} bottom={74} />
  </SceneShell>
);
