import { Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/NotoSansBengali";

const bn = loadFont("normal", { weights: ["500", "700", "900"], subsets: ["bengali", "latin"] });

export const FPS = 60;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// Scene cut points (seconds) measured on the 46.76s reference voiceover (snapped to real pauses).
// Used ONLY as ratios: real scene frames are derived from the actual audio duration at render time.
const REF_SECONDS = [0, 7.58, 18.1, 30.16, 40.35, 46.76];

export const theme = {
  colors: {
    bg: "#02070D",
    bgAlt: "#06141F",
    deep: "#03243A",
    primary: "#00F3FF", // hero
    danger: "#FF1E27",
    warn: "#FFB800",
    text: "#EAFBFF",
    textDim: "#7FA4B3",
  },
  fonts: {
    bn: bn.fontFamily,
    mono: "'Courier New', monospace",
    serif: "Georgia, 'Times New Roman', serif",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
    stamp: { damping: 9, stiffness: 220, mass: 0.7 },
  },
} as const;

export const getSceneFrames = (totalFrames: number) =>
  REF_SECONDS.slice(0, -1).map((sec, i) => {
    const last = REF_SECONDS[REF_SECONDS.length - 1];
    const from = Math.round((sec / last) * totalFrames);
    const end =
      i === REF_SECONDS.length - 2 ? totalFrames : Math.round((REF_SECONDS[i + 1] / last) * totalFrames);
    return { from, duration: end - from };
  });
