import React, { useMemo } from "react";
import { AbsoluteFill, random, useCurrentFrame } from "remotion";
import { HEIGHT, WIDTH, theme } from "../theme";

/** LAYER 0 — abyssal gradient + volumetric god-rays. depth 0..1 darkens and kills the rays. */
export const Abyss: React.FC<{ depth: number }> = ({ depth }) => {
  const frame = useCurrentFrame();
  const rays = Array.from({ length: 9 }, (_, i) => i);
  const rayAlpha = 1 - depth * 0.9;
  return (
    <AbsoluteFill
      style={{
        background: `linear-gradient(180deg, ${theme.colors.deep} 0%, ${theme.colors.bgAlt} 48%, ${theme.colors.bg} 100%)`,
      }}
    >
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse at 50% -10%, ${theme.colors.primary}40, transparent 62%)`,
          opacity: 1 - depth,
        }}
      />
      {rays.map((i) => {
        const sway = Math.sin(frame / (140 + i * 17) + i * 1.7) * 5;
        const pulse = 0.55 + 0.45 * Math.sin(frame / (60 + i * 9) + i);
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              top: -120,
              left: `${6 + i * 11}%`,
              width: 120 + (i % 3) * 90,
              height: 1500,
              transformOrigin: "50% 0%",
              transform: `rotate(${-24 + i * 6 + sway}deg)`,
              background: `linear-gradient(180deg, ${theme.colors.primary}38 0%, ${theme.colors.primary}10 45%, transparent 85%)`,
              filter: "blur(22px)",
              opacity: pulse * rayAlpha,
              mixBlendMode: "screen",
            }}
          />
        );
      })}
      <AbsoluteFill style={{ background: "#000", opacity: depth * 0.5 }} />
    </AbsoluteFill>
  );
};

/** LAYER 1 — 3D perspective tactical grid rolling toward the camera */
export const Grid3D: React.FC<{ fade?: number }> = ({ fade = 1 }) => {
  const frame = useCurrentFrame();
  const offset = (frame * 0.9) % 80;
  const c = theme.colors.primary;
  const mask = "linear-gradient(180deg, transparent 0%, #000 30%, #000 100%)";
  return (
    <AbsoluteFill
      style={{
        perspective: 900,
        perspectiveOrigin: "50% 38%",
        overflow: "hidden",
        opacity: 0.55 * fade,
      }}
    >
      <div
        style={{
          position: "absolute",
          left: "-50%",
          width: "200%",
          top: "44%",
          height: "150%",
          transformOrigin: "50% 0%",
          transform: "rotateX(72deg)",
          backgroundImage: `linear-gradient(${c}55 2px, transparent 2px), linear-gradient(90deg, ${c}55 2px, transparent 2px)`,
          backgroundSize: "80px 80px",
          backgroundPosition: `0px ${offset}px`,
          maskImage: mask,
          WebkitMaskImage: mask,
        }}
      />
    </AbsoluteFill>
  );
};

/** LAYER 2 — bioluminescent dust + bubbles (deterministic) */
const COUNT = 80;
export const Particles: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {Array.from({ length: COUNT }, (_, i) => {
        const x0 = random(`px${i}`) * WIDTH;
        const size = 2 + random(`ps${i}`) * 6;
        const spd = 0.35 + random(`pv${i}`) * 0.9;
        const ph = random(`pp${i}`) * (HEIGHT + 200);
        const y = HEIGHT + 100 - ((frame * spd * 0.7 + ph) % (HEIGHT + 200));
        const x = x0 + Math.sin(frame / (50 + random(`pw${i}`) * 60) + i) * 24;
        const bubble = i % 3 === 0;
        const col = i % 7 === 0 ? theme.colors.warn : theme.colors.primary;
        const tw = 0.4 + 0.6 * Math.abs(Math.sin(frame / (30 + (i % 9) * 6) + i));
        const d = size * (bubble ? 2.2 : 1);
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x,
              top: y,
              width: d,
              height: d,
              borderRadius: "50%",
              background: bubble ? "transparent" : col,
              border: bubble ? `1.5px solid ${col}99` : "none",
              boxShadow: `0 0 ${size * 3}px ${col}`,
              opacity: tw * (bubble ? 0.7 : 0.85),
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/** Colour grade (above content) */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill
      style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.18 }}
    />
    <AbsoluteFill
      style={{
        background:
          "linear-gradient(180deg, rgba(0,0,0,0.18), transparent 28%, transparent 70%, rgba(0,0,0,0.28))",
      }}
    />
  </AbsoluteFill>
);

/** Broadcast scanlines */
export const Scanlines: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      backgroundImage:
        "repeating-linear-gradient(180deg, rgba(0,0,0,0.16) 0px, rgba(0,0,0,0.16) 1px, transparent 1px, transparent 4px)",
      opacity: 0.5,
    }}
  />
);

/** Film grain — pure SVG pattern of deterministic specks (no feTurbulence, no assets) */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const specks = useMemo(
    () =>
      Array.from({ length: 170 }, (_, i) => ({
        x: random(`gx${i}`) * 200,
        y: random(`gy${i}`) * 200,
        o: 0.25 + random(`go${i}`) * 0.75,
        s: 1 + Math.floor(random(`gs${i}`) * 2),
      })),
    []
  );
  const ox = (frame * 37) % 200;
  const oy = (frame * 53) % 200;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", mixBlendMode: "screen", opacity: 0.1 }}>
      <svg width={WIDTH} height={HEIGHT}>
        <defs>
          <pattern
            id="grainPattern"
            width="200"
            height="200"
            patternUnits="userSpaceOnUse"
            patternTransform={`translate(${ox} ${oy})`}
          >
            {specks.map((s, i) => (
              <rect key={i} x={s.x} y={s.y} width={s.s} height={s.s} fill="#ffffff" opacity={s.o} />
            ))}
          </pattern>
        </defs>
        <rect width={WIDTH} height={HEIGHT} fill="url(#grainPattern)" />
      </svg>
    </AbsoluteFill>
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: "radial-gradient(ellipse at center, transparent 52%, rgba(0,0,0,0.55) 100%)",
    }}
  />
);

/** RGB-glitch overlay for scene cuts */
export const GlitchCut: React.FC<{ amount: number; seed: number }> = ({ amount, seed }) => {
  if (amount < 0.02) return null;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      <AbsoluteFill style={{ background: "#fff", mixBlendMode: "screen", opacity: amount * 0.22 }} />
      {Array.from({ length: 9 }, (_, i) => {
        const top = random(`gt${seed}-${i}`) * HEIGHT;
        const h = 14 + random(`gh${seed}-${i}`) * 100;
        const dx = (random(`gd${seed}-${i}`) - 0.5) * 260 * amount;
        const col = i % 3 === 0 ? theme.colors.danger : theme.colors.primary;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: dx,
              top,
              width: WIDTH,
              height: h,
              background: `${col}${i % 2 ? "55" : "33"}`,
              mixBlendMode: "screen",
              opacity: amount,
            }}
          />
        );
      })}
      <div
        style={{
          position: "absolute",
          left: 0,
          top: random(`gl${seed}`) * HEIGHT,
          width: WIDTH,
          height: 3,
          background: "#fff",
          opacity: amount * 0.8,
        }}
      />
    </AbsoluteFill>
  );
};
