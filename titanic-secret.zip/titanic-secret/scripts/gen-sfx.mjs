// Synthesises a copyright-free SFX kit (16-bit mono WAV) into public/sfx. Deterministic, zero downloads.
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const out = path.join(process.cwd(), "public", "sfx");
fs.mkdirSync(out, { recursive: true });

let seed = 1337;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const buf = (sec) => new Float32Array(Math.floor(sec * SR));

const write = (name, data) => {
  let peak = 0;
  for (const v of data) peak = Math.max(peak, Math.abs(v));
  const k = peak > 0 ? 0.9 / peak : 1;
  const pcm = Buffer.alloc(44 + data.length * 2);
  pcm.write("RIFF", 0);
  pcm.writeUInt32LE(36 + data.length * 2, 4);
  pcm.write("WAVEfmt ", 8);
  pcm.writeUInt32LE(16, 16);
  pcm.writeUInt16LE(1, 20);
  pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(SR, 24);
  pcm.writeUInt32LE(SR * 2, 28);
  pcm.writeUInt16LE(2, 32);
  pcm.writeUInt16LE(16, 34);
  pcm.write("data", 36);
  pcm.writeUInt32LE(data.length * 2, 40);
  for (let i = 0; i < data.length; i++) pcm.writeInt16LE(Math.round(Math.max(-1, Math.min(1, data[i] * k)) * 32767), 44 + i * 2);
  fs.writeFileSync(path.join(out, `${name}.wav`), pcm);
};

// state-variable band-pass
const bandpass = (x, centerAt, q = 4) => {
  const y = new Float32Array(x.length);
  let low = 0;
  let band = 0;
  for (let i = 0; i < x.length; i++) {
    const fc = centerAt(i / x.length);
    const ff = 2 * Math.sin((Math.PI * fc) / SR);
    low += ff * band;
    const high = x[i] - low - band / q;
    band += ff * high;
    y[i] = band;
  }
  return y;
};

const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  const y = new Float32Array(x.length);
  let s = 0;
  for (let i = 0; i < x.length; i++) y[i] = s += a * (x[i] - s);
  return y;
};

// whoosh
{
  const n = buf(0.8);
  for (let i = 0; i < n.length; i++) n[i] = rnd();
  const y = bandpass(n, (t) => 250 + 3200 * t * t, 3);
  for (let i = 0; i < y.length; i++) {
    const t = i / y.length;
    y[i] *= Math.sin(Math.PI * Math.pow(t, 0.7));
  }
  write("whoosh", y);
}
// stamp
{
  const y = buf(0.7);
  let ph = 0;
  for (let i = 0; i < y.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (45 + 90 * Math.exp(-t * 18))) / SR;
    y[i] = Math.sin(ph) * Math.exp(-t * 6) + (t < 0.03 ? rnd() * (1 - t / 0.03) * 0.6 : 0);
  }
  write("stamp", y);
}
// impact
{
  const y = buf(1.5);
  const nz = new Float32Array(y.length);
  for (let i = 0; i < nz.length; i++) nz[i] = rnd();
  const low = lowpass(nz, 500);
  let ph = 0;
  for (let i = 0; i < y.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (32 + 60 * Math.exp(-t * 10))) / SR;
    y[i] = Math.sin(ph) * Math.exp(-t * 3.2) + low[i] * 1.6 * Math.exp(-t * 7);
  }
  write("impact", y);
}
// snap
{
  const y = buf(0.9);
  const nz = new Float32Array(y.length);
  for (let i = 0; i < nz.length; i++) nz[i] = rnd();
  const hp = bandpass(nz, () => 2600, 1.2);
  const clicks = [0, 0.05, 0.11, 0.19, 0.3];
  for (let i = 0; i < y.length; i++) {
    const t = i / SR;
    let env = 0;
    for (const c of clicks) if (t >= c) env += Math.exp(-(t - c) * 55) * (c === 0 ? 1 : 0.55);
    y[i] = hp[i] * env + Math.sin(2 * Math.PI * 110 * t) * Math.exp(-t * 8) * 0.8;
  }
  write("snap", y);
}
// sonar ping
{
  const y = buf(2.2);
  for (let i = 0; i < y.length; i++) {
    const t = i / SR;
    const tone = (tt) => (tt < 0 ? 0 : (Math.sin(2 * Math.PI * 1400 * tt) + 0.35 * Math.sin(2 * Math.PI * 2800 * tt)) * Math.exp(-tt * 3.2));
    y[i] = tone(t) + 0.45 * tone(t - 0.38) + 0.2 * tone(t - 0.76);
  }
  write("ping", y);
}
// tick
{
  const y = buf(0.09);
  for (let i = 0; i < y.length; i++) {
    const t = i / SR;
    y[i] = Math.sin(2 * Math.PI * 2400 * t) * Math.exp(-t * 90);
  }
  write("tick", y);
}
// pop
{
  const y = buf(0.32);
  let ph = 0;
  for (let i = 0; i < y.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (260 + 700 * Math.exp(-t * 28))) / SR;
    y[i] = Math.sin(ph) * Math.exp(-t * 14);
  }
  write("pop", y);
}
// glitch
{
  const y = buf(0.4);
  let hold = 0;
  for (let i = 0; i < y.length; i++) {
    const t = i / SR;
    if (i % 24 === 0) hold = Math.round(rnd() * 4) / 4;
    const gate = Math.sin(t * 90) > -0.2 && Math.sin(t * 37) > -0.5 ? 1 : 0;
    y[i] = hold * gate * Math.sin(Math.PI * (t / 0.4));
  }
  write("glitch", y);
}
console.log("SFX written to", out);
