import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { Counter, Entrance, NeonCaption, SceneShell, Sfx, Stamp, prog } from "../components/Motion";
import { ShipSvg } from "../components/Ship";
import { STAMP_LAND, f } from "../timeline";
import { theme } from "../theme";

const TITLE = "টাইটানিক ডোবার আসল রহস্য: যা তোমাকে কখনও বলা হয়নি!";
const STAMP_AT = f(3.1);

const Card: React.FC<{ label: string; delay: number; children: React.ReactNode }> = ({ label, delay, children }) => (
  <Entrance delay={delay} y={50}>
    <div
      style={{
        width: 420,
        padding: "16px 24px",
        border: `2px solid ${theme.colors.primary}88`,
        borderRadius: 10,
        background: "rgba(2,20,31,0.62)",
        boxShadow: `0 0 24px ${theme.colors.primary}33, inset 0 0 20px ${theme.colors.primary}1a`,
        fontFamily: theme.fonts.mono,
        textAlign: "center",
      }}
    >
      <div style={{ fontSize: 16, letterSpacing: "0.18em", color: theme.colors.textDim }}>{label}</div>
      <div style={{ fontSize: 40, fontWeight: 700, color: theme.colors.primary, textShadow: `0 0 14px ${theme.colors.primary}` }}>
        {children}
      </div>
    </div>
  </Entrance>
);

export const Scene1: React.FC = () => {
  const frame = useCurrentFrame();
  const draw = prog(frame, f(0.1), f(3.0));
  const dim = prog(frame, f(2.6), f(3.4));
  return (
    <SceneShell shakes={[STAMP_AT + STAMP_LAND]} zoom={[1.02, 1.07]}>
      <Sfx name="whoosh" at={f(0.05)} volume={0.35} />
      <Sfx name="stamp" at={STAMP_AT + STAMP_LAND - 3} volume={0.7} />

      <AbsoluteFill style={{ alignItems: "center" }}>
        <div style={{ marginTop: 116, opacity: 0.55 + 0.45 * Math.min(1, draw * 2) }}>
          <ShipSvg progress={draw} width={1320} />
        </div>
        {/* dimension line */}
        <svg width={1320} height={60} viewBox="0 0 1320 60" style={{ position: "absolute", top: 478, opacity: dim }}>
          <path d="M70 30 L1250 30 M70 14 L70 46 M1250 14 L1250 46" stroke={theme.colors.warn} strokeWidth={2.5} fill="none" />
          <text x={660} y={22} textAnchor="middle" fill={theme.colors.warn} fontFamily={theme.fonts.mono} fontWeight={700} fontSize={20} letterSpacing={4}>
            882 FT 9 IN / 269 M
          </text>
        </svg>
      </AbsoluteFill>

      <AbsoluteFill style={{ justifyContent: "flex-start", alignItems: "center", paddingTop: 556 }}>
        <div style={{ display: "flex", gap: 36 }}>
          <Card label="TONNAGE (GRT)" delay={f(1.4)}>
            <Counter to={46328} delay={f(1.4)} />
          </Card>
          <Card label="BEAM (FT)" delay={f(1.5)}>
            <Counter to={92.5} decimals={1} delay={f(1.5)} />
          </Card>
          <Card label="STATUS" delay={f(1.6)}>
            <span style={{ color: theme.colors.warn, textShadow: `0 0 14px ${theme.colors.warn}` }}>"UNSINKABLE"</span>
          </Card>
        </div>
      </AbsoluteFill>

      <Stamp text="UNSINKABLE?" color={theme.colors.danger} at={STAMP_AT} x="50%" y="38%" rotate={-8} size={132} />
      <NeonCaption text={TITLE} delay={f(4.0)} size={56} width={1640} bottom={84} />
    </SceneShell>
  );
};
