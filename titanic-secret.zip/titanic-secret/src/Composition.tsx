import React from "react";
import { AbsoluteFill, Audio, Sequence, random, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { HUD } from "./components/HUD";
import { Abyss, GlitchCut, Grade, Grain, Grid3D, Particles, Scanlines, Vignette } from "./components/Layers";
import { Sfx } from "./components/Motion";
import { Scene1 } from "./scenes/Scene1";
import { Scene2 } from "./scenes/Scene2";
import { Scene3 } from "./scenes/Scene3";
import { Scene4 } from "./scenes/Scene4";
import { Scene5 } from "./scenes/Scene5";
import { getSceneFrames, theme } from "./theme";
import { depthAt, f, glitchAmount } from "./timeline";

export type MainProps = { audioSrc: string };

const SCENES: React.FC[] = [Scene1, Scene2, Scene3, Scene4, Scene5];

export const MainComposition: React.FC<MainProps> = ({ audioSrc }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const scenes = getSceneFrames(durationInFrames);
  const cuts = scenes.slice(1).map((s) => s.from);
  const g = glitchAmount(frame, cuts);
  const depth = depthAt(frame, durationInFrames) / 3800;
  const jitter = (random(`jit${frame}`) - 0.5) * 44 * g;

  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <Audio src={staticFile(audioSrc)} />

      {/* L0 – L3 */}
      <AbsoluteFill
        style={{
          transform: `translateX(${jitter}px)`,
          filter: g > 0.02 ? `saturate(${1 + g}) hue-rotate(${g * 40}deg)` : undefined,
        }}
      >
        <Abyss depth={depth} />
        <Grid3D fade={1 - depth * 0.7} />
        <Particles />
        {scenes.map((s, i) => {
          const Scene = SCENES[i];
          return (
            <Sequence key={i} from={s.from} durationInFrames={s.duration}>
              <Scene />
            </Sequence>
          );
        })}
      </AbsoluteFill>

      {/* L4 */}
      <HUD />

      {/* grade / texture / glitch */}
      <Grade />
      <Scanlines />
      <Grain />
      <Vignette />
      <GlitchCut amount={g} seed={frame} />

      {cuts.map((c) => (
        <Sfx key={c} name="glitch" at={c - f(0.12)} volume={0.35} />
      ))}
    </AbsoluteFill>
  );
};
