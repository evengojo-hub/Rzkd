import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Counter, Entrance, NeonCaption, SceneShell, Sfx, Stamp, prog } from "../components/Motion";
import { ShipSvg } from "../components/Ship";
import { STAMP_LAND, f } from "../timeline";
import { theme } from "../theme";

const TEXT = "এটি কি নিছকই একটি দুর্ঘটনা ছিল, নাকি ইতিহাসের সবচেয়ে বড় ইন্স্যুরেন্স স্ক্যাম?";
const FILE = "FILE #1912-OLYMPIC";
const STAMP_AT = f(5.0);

const Row: React.FC<{ label: string; delay: number; color: string; children: React.ReactNode }> = ({
  label,
  delay,
  color,
  children,
}) => (
  <Entrance delay={delay} y={24}>
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "7px 18px",
        borderBottom: `1px solid ${color}44`,
        fontFamily: theme.fonts.mono,
        fontWeight: 700,
        fontSize: 22,
        letterSpacing: "0.08em",
      }}
    >
      <span style={{ color: theme.colors.textDim }}>{label}</span>
      <span style={{ color, textShadow: `0 0 10px ${color}` }}>{children}</span>
    </div>
  </Entrance>
);

const Panel: React.FC<{
  title: string;
  color: string;
  left: number;
  progress: number;
  reveal: number;
  rows: { label: string; node: React.ReactNode }[];
  delay: number;
}> = ({ title, color, left, progress, reveal, rows, delay }) => (
  <div
    style={{
      position: "absolute",
      left,
      top: 204,
      width: 830,
      height: 420,
      border: `2px solid ${color}88`,
      borderRadius: 14,
      background: "rgba(2,20,31,0.55)",
      boxShadow: `0 0 30px ${color}33, inset 0 0 40px ${color}14`,
      clipPath: `inset(0 ${(1 - reveal) * 50}% 0 ${(1 - reveal) * 50}%)`,
      padding: "12px 0",
    }}
  >
    <div style={{ textAlign: "center", fontFamily: theme.fonts.mono, fontWeight: 700, fontSize: 30, letterSpacing: "0.2em", color, textShadow: `0 0 14px ${color}` }}>
      {title}
    </div>
    <div style={{ display: "flex", justifyContent: "center", marginTop: 4 }}>
      <ShipSvg width={700} color={color} progress={progress} glow={8} />
    </div>
    <div style={{ marginTop: 6 }}>
      {rows.map((r, i) => (
        <Row key={r.label} label={r.label} delay={delay + i * 5} color={color}>
          {r.node}
        </Row>
      ))}
    </div>
  </div>
);

export const Scene4: React.FC = () => {
  const frame = useCurrentFrame();
  const typed = Math.floor(prog(frame, f(0.3), f(1.3), theme.ease.out) * FILE.length);
  const reveal = prog(frame, f(0.9), f(1.7), theme.ease.out);
  const draw = prog(frame, f(1.5), f(3.2));
  const scan = interpolate(frame, [f(0.9), f(1.9)], [0, 1], {
    easing: theme.ease.inOut,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const cursor = Math.sin(frame / 7) > 0 ? "█" : " ";
  const rowDelay = f(2.6);
  return (
    <SceneShell shakes={[STAMP_AT + STAMP_LAND]} zoom={[1.02, 1.07]}>
      <Sfx name="whoosh" at={f(0.1)} volume={0.35} />
      <Sfx name="tick" at={f(0.4)} volume={0.3} />
      <Sfx name="whoosh" at={f(0.9)} volume={0.3} />
      <Sfx name="stamp" at={STAMP_AT + STAMP_LAND - 3} volume={0.75} />
      <Sfx name="pop" at={f(5.9)} volume={0.35} />

      {/* dossier tab */}
      <div style={{ position: "absolute", left: 110, top: 96 }}>
        <Entrance delay={f(0.1)} x={-50} y={0}>
          <div
            style={{
              display: "inline-block",
              padding: "6px 34px",
              border: `3px solid ${theme.colors.warn}`,
              borderRadius: "10px 10px 0 0",
              background: "rgba(2,20,31,0.7)",
              fontFamily: theme.fonts.mono,
              fontWeight: 700,
              fontSize: 54,
              letterSpacing: "0.12em",
              color: theme.colors.warn,
              textShadow: `0 0 16px ${theme.colors.warn}`,
              boxShadow: `0 0 28px ${theme.colors.warn}44`,
            }}
          >
            {FILE.slice(0, typed)}
            {cursor}
          </div>
        </Entrance>
      </div>
      <div style={{ position: "absolute", right: 110, top: 118 }}>
        <Entrance delay={f(0.5)} x={50} y={0}>
          <div style={{ fontFamily: theme.fonts.mono, fontWeight: 700, fontSize: 22, letterSpacing: "0.2em", color: theme.colors.danger, textShadow: `0 0 12px ${theme.colors.danger}` }}>
            CLASSIFIED // THEORY — UNVERIFIED
          </div>
        </Entrance>
      </div>

      {/* split-screen */}
      <Panel
        title="RMS OLYMPIC"
        color={theme.colors.primary}
        left={100}
        progress={draw}
        reveal={reveal}
        delay={rowDelay}
        rows={[
          { label: "GROSS TONNAGE", node: <Counter to={45324} delay={rowDelay} /> },
          { label: "COMPLETED", node: "1911" },
          { label: "INCIDENT", node: "HAWKE COLLISION" },
        ]}
      />
      <Panel
        title="RMS TITANIC"
        color={theme.colors.warn}
        left={990}
        progress={draw}
        reveal={reveal}
        delay={rowDelay + 4}
        rows={[
          { label: "GROSS TONNAGE", node: <Counter to={46328} delay={rowDelay + 4} /> },
          { label: "COMPLETED", node: "1912" },
          { label: "INCIDENT", node: "SINKING" },
        ]}
      />
      {/* divider + scan line */}
      <div
        style={{
          position: "absolute",
          left: 958,
          top: 190,
          width: 4,
          height: 450,
          background: theme.colors.text,
          boxShadow: `0 0 20px ${theme.colors.primary}, 0 0 50px ${theme.colors.primary}`,
          opacity: reveal,
        }}
      />
      <div
        style={{
          position: "absolute",
          left: 100 + scan * 1640,
          top: 190,
          width: 3,
          height: 450,
          background: theme.colors.primary,
          boxShadow: `0 0 24px ${theme.colors.primary}`,
          opacity: scan < 1 ? 1 - Math.abs(scan - 0.5) * 0.6 : 0,
        }}
      />

      {/* insurance stat strip */}
      <AbsoluteFill style={{ justifyContent: "flex-start", alignItems: "center", paddingTop: 662 }}>
        <Entrance delay={f(5.6)} y={40}>
          <div
            style={{
              padding: "10px 44px",
              border: `2px solid ${theme.colors.danger}`,
              borderRadius: 10,
              background: "rgba(40,4,6,0.6)",
              boxShadow: `0 0 30px ${theme.colors.danger}55`,
              fontFamily: theme.fonts.mono,
              fontWeight: 700,
              fontSize: 36,
              letterSpacing: "0.1em",
              color: theme.colors.text,
            }}
          >
            INSURED ≈{" "}
            <Counter
              to={1000000}
              prefix="£"
              delay={f(5.6)}
              style={{ color: theme.colors.danger, textShadow: `0 0 14px ${theme.colors.danger}` }}
            />
          </div>
        </Entrance>
      </AbsoluteFill>

      <Stamp text="INSURANCE SCAM?" color={theme.colors.danger} at={STAMP_AT} x="50%" y="40%" rotate={-6} size={112} />
      <NeonCaption text={TEXT} delay={f(1.2)} size={50} width={1640} color={theme.colors.warn} bottom={70} />
    </SceneShell>
  );
};
