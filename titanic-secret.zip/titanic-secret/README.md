# titanic-secret

```
sh scripts/install-linux-deps.sh   # Codespaces / Debian only, once
npm install
npm run dev                        # Remotion Studio
npm run build                      # out/titanic-secret.mp4
```

Put your voiceover at `public/voice.mp3` — video length = audio length (read at render time).
